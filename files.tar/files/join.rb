require './everbase.so'
begin
	Everbase::startup([]) #Kernel should already run

	profile = Everbase::CoreSystem::Profile::primary()
	jd = Everbase::CoreSystem::JoinableDomain::all()
	j = jd[0]
	profile.create_device( j, 'bob laptop', Everbase::CoreSystem::DeviceRole::PEER )
	profile.send_join_request_with_user( j, 'bob', 'another passphrase', '')
	profile.accept_domain()

	Everbase::shutdown()

	$stdout.puts "Ruby: Join successful done"

rescue Exception => e
	$stderr.puts e
end