require './everbase.so'
begin
	Everbase::startup([]) # Kernel should be still running

	domain = Everbase::CoreSystem::Domain.open('mydomain.de')
	joinRequests = Everbase::CoreSystem::JoinRequest.pending()
	joinRequests[0].accept( domain )

	Everbase::shutdown()

	$stdout.puts "Ruby: Join accepted"
rescue Exception => e
	$stderr.puts e
	$stderr.puts e.backtrace
end