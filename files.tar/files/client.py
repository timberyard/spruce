import os
import sys
import time
import shutil
import logging
import subprocess
from spruce_util import *
from spruce_netcfg_client import *

HOST_IP = "192.168.0.226"
HOST_IP = "192.168.122.1" # IP in default virbr0 instead local LAN IP

logging.basicConfig(format='%(levelname)s : %(name)s : %(message)s', filename="client.log", level=logging.INFO)

try:
	# subprocess.Popen(["nohup", "screen", "-dmS", "kernel", "/mnt/everbase_kernel"])
	process = subprocess.Popen("su - root -c 'nohup screen -dmS kernel /mnt/everbase_kernel -l2 --profile-path /mnt/client'", shell=True)
	out = process.communicate()
	if out[1]:
		logging.error("ERROR BACKLOG STARING HERE")
		for line in (out[1].split("\n")):
			if line:
				logging.error("Kernel: " + line)
		logging.error("ERROR BACKLOG ENDING HERE")
		raise Exception("Error starting filesystem")

	logging.info("kernel started")
	time.sleep(2) #wait for screen being created

#################################################################################

	command = "ruby /mnt/init.rb" #Init and create domain
	process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
	out = process.communicate() # [0] -> stdout [1] -> stderr
	#logging.info(out[0])
	if out[1]:
		logging.error("ERROR BACKLOG STARING HERE")
		for line in (out[1].split("\n")):
			if line:
				logging.error("Ruby Init: " + line)
		logging.error("ERROR BACKLOG ENDING HERE")
	 	raise Exception('Error initializing client')
	logging.info("initialized server")

#################################################################################

	# WAIT TILL WORKAROUND / CREATING DOMAIN ON SERVER IS DONE
	timeout = breakListen("ready", 100.0) # Timeout after 100 seconds
	if timeout == 1:
	 	raise Exception('BreakListen for "ready" timed out after 100 seconds')
	logging.info("got ready message")

#################################################################################

	command = "ruby /mnt/join.rb"
	process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
	out = process.communicate()
	#logging.info(out[0])
	if out[1]:
		logging.error("ERROR BACKLOG STARING HERE")
		for line in (out[1].split("\n")):
			if line:
				logging.error("Ruby Join Job: " + line)
		logging.error("ERROR BACKLOG ENDING HERE")
	 	raise Exception('Error doing join job')

	logging.info("completed join.rb")

#################################################################################

	serverIp = getVmIpAddr("joinRequest", "server")
	breakSend(serverIp, "Joined domain")
	logging.info("sent joined domain info to {}".format(serverIp))

#################################################################################

	# subprocess.Popen(["nohup", "screen", "-X", "-S", "kernel", "quit"])

	#sendStatus("[finish]")

#################################################################################

except:
	e = sys.exc_info()[1]
	logging.error(str(e))
	sendStatus("[error] - Terminating client.py: " + str(e))

finally:
	try:
		with open("client.log", 'r') as l:
			for line in l:
				if "[error]" in line.split("-")[0]:
					sendStatus("[error] - {}".format(line))
				else:
					sendStatus("[info] - {}".format(line))
	except Exception, err:
		sendStatus(traceback.format_exc())

	subprocess.Popen("su - root -c 'nohup screen -X -S kernel quit'", shell=True)
	time.sleep(2)
	logging.info("kernel stopped")

	if os.path.exists("/home/tester/.everbase"):
		shutil.rmtree("/home/everbase/.everbase")
		logging.info("deleted .everbase folder")
	else:
		logging.info("no .everbase directory found, so none got deleted")

	sys.exit(0)
