require './everbase.so'
require 'timeout'

begin
    def startup(i)
        begin
            Timeout::timeout(0.2) do
                if i == 0
                    begin
                        Everbase::startup([])
                        i = 1
                        $stdout.puts "Ruby: Everbase started"
                    # rescue Exception => e
                    rescue
                       # p e #Debug output
                        Everbase::shutdown()
                        startup(0)
                    end
                end
            end
        rescue Timeout::Error
            p "ruby startup function timed out"
            return
        end
    end

    sleep(5)
    startup(0)
    Everbase::shutdown()

    $stdout.puts "Ruby: Initialized client"
rescue Exception => e
   # $stderr.puts e
    p e
end