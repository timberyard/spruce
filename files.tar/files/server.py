import os
import sys
import time
import shutil
import urllib
import logging
import traceback
import subprocess
from spruce_util import *
from spruce_netcfg_client import *

HOST_IP	= "192.168.0.226"
HOST_IP = "192.168.122.1"

logging.basicConfig(format='%(levelname)s : %(name)s : %(message)s', filename="server.log", level=logging.INFO)

try:
	# subprocess.Popen(["su", "-", "root", "-c", "'nohup", "screen", "-dmS", "kernel", "/mnt/everbase_kernel'"])
	process = subprocess.Popen("su - root -c 'nohup screen -dmS kernel /mnt/everbase_kernel -l2  --process-join-requests --profile-path /mnt/server'", shell=True)
	out = process.communicate()
	if out[1]:
		logging.error("ERROR BACKLOG STARING HERE")
		for line in (out[1].split("\n")):
			if line:
				logging.error("Kernel: " + line)
		logging.error("ERROR BACKLOG ENDING HERE")
		raise Exception("Error starting filesystem")

	logging.info("kernel started")
	time.sleep(2)

#################################################################################

	command = "ruby /mnt/init_server.rb" #Init and create domain
	process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
	out = process.communicate()
	#logging.info(out[0])
	if out[1]:
		logging.error("ERROR BACKLOG STARING HERE")
		for line in (out[1].split("\n")):
			if line:
				logging.error("Ruby Init Server: " + line)
		logging.error("ERROR BACKLOG ENDING HERE")
		raise Exception("Error initializing server")

	logging.info("initialized server")

	process = subprocess.Popen("su - root -c 'nohup screen -dmS kernel /mnt/everbase_filesystem -l2'", shell=True)
	out = process.communicate()
		
	if out[1]:
		logging.error("ERROR BACKLOG STARING HERE")
		for line in (out[1].split("\n")):
			if line:
				logging.error("Filesystem: " + line)
		logging.error("ERROR BACKLOG ENDING HERE")
		raise Exception("Error starting filesystem")

	logging.info("filesystem started")
	time.sleep(2)

#	urllib.urlretrieve("http://web4host.net/20MB.zip", "/mnt/Everbase/mydomain.de/20MB.zip")

#	logging.info("initialized server")

#################################################################################

	# WAIT TILL THE CLIENT JOINED THE DOMAIN
	clientIp = getVmIpAddr("joinRequest", "client")
	breakSend(clientIp, "ready")
	logging.info("sent ready message to {}".format(clientIp))

	timeout = breakListen("Joined domain", 100.0)
	if timeout == 1:
		raise Exception('BreakListen for "Joined domain" timed out after 100 seconds')
	logging.info("got joined domain info")

#################################################################################

	command = "ruby /mnt/accept.rb"
	process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE) #, stderr=subprocess.PIPE)
	out = process.communicate()
	#logging.info(out[0])
	if out[1]:
		logging.error("ERROR BACKLOG STARING HERE")
		for line in (out[1].split("\n")):
			if line:
				logging.error("Ruby Accept Job: " + line)
		logging.error("ERROR BACKLOG ENDING HERE")
	 	raise Exception('Error doing accept job')

#################################################################################

except:
	e = sys.exc_info()[1]
	logging.error(str(e))
	sendStatus("[error] - Terminating server.py: " + str(e))

finally:
	try:
		with open("server.log", 'r') as l:
			for line in l:
				if "[error]" in line.split("-")[0]:
					sendStatus("[error] - {}".format(line))
				else:
					sendStatus("[info] - {}".format(line))
	except Exception, err:
		sendStatus(traceback.format_exc())

	subprocess.Popen("su - root -c 'nohup screen -X -S kernel quit'", shell=True)
	time.sleep(2)
	logging.info("kernel stopped")

	if os.path.exists("/home/tester/.everbase"):
		shutil.rmtree("/home/everbase/.everbase")
		logging.info("deleted .everbase folder")
	else:
		logging.info("no .everbase directory found, so none got deleted")
	
	sys.exit(0)
